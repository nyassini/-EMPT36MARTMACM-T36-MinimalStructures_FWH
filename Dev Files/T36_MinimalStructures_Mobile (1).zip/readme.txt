Files:

1. variation1.html - this is the code optimizely used to do dom manipulation for variation 1.
2. variation2.html - this is the code optimizely used to do dom manipulation for variation 2. 
3. frontend-v1-after-dom-manipulation.html - this is new html sections after dom manipulation for variation 1. 
4. frontend-v2-after-dom-manipulation.html - this is new html sections after dom manipulation for variation 1. 
